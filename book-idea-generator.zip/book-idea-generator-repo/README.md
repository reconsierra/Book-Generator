# 📚 Book Idea Generator

An AI-powered book idea and development tool built as a single-file HTML application. No server required — just open in a browser.

## Features

- **13 genres** with deep sub-genre and craft controls
- **AI pitch generation** — back-cover blurbs and title suggestions via Claude API
- **Series Manager** — generate multi-book series briefs with recurring characters and overarching arcs
- **Develop This Book** — 10-document AI-powered development suite per book:
  - 1-Page Synopsis
  - 3-Page Synopsis
  - Chapter Outline
  - Character Profiles
  - World Bible
  - Query Letter
  - Opening Chapter
  - Cover Art Brief
  - Marketing Copy
  - Sensitivity Notes
- **📚 Develop Entire Series** — generate all development documents for every book in a series in one run, with per-book tab navigation
- **⬆ Export MD** — export all documents as Markdown, with optional Google Drive or OneDrive upload
- **Presets** — save and load full configurations
- **PDF export** — print-ready PDFs of briefs and development docs
- **Import/Export JSON** — share or back up your configurations
- **Content restrictions** — taboo topic system with saveable defaults

## Setup

### Basic Use (No API Key)
Open `index.html` in any modern browser. Template-based pitch generation works immediately.

### With AI (Anthropic API Key)
1. Get an API key at [console.anthropic.com](https://console.anthropic.com)
2. Click **🔑 Set API Key** in the toolbar
3. Enter your key — it's stored only in your browser's localStorage

Uses `claude-sonnet-4-20250514`.

### Cloud Export (Optional)

**Google Drive:**
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project → enable the Drive API
3. Create OAuth 2.0 credentials (Web application type)
4. Add your GitHub Pages URL to Authorised JavaScript Origins
5. Paste the Client ID into the Export MD modal

**OneDrive:**
1. Go to [Azure Portal](https://portal.azure.com)
2. App registrations → New registration
3. Add `Files.ReadWrite` scope under API permissions
4. Set redirect URI to your GitHub Pages URL
5. Paste the Application (client) ID into the Export MD modal

## Deployment

### GitHub Pages
1. Push this repo to GitHub
2. Go to Settings → Pages → Source: `main` branch, `/ (root)`
3. Your tool will be live at `https://yourusername.github.io/repo-name`

For cloud export (Google Drive / OneDrive), add your GitHub Pages URL as an authorised origin in your app registrations.

## Usage

No build step, no dependencies, no server. Everything runs client-side. The only external requests are:
- Google Fonts (for typography)
- Anthropic API (when AI features are used)
- Google Drive API / Microsoft Graph API (when cloud export is used)

## License

MIT
